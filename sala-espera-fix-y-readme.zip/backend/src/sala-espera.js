// Lógica de la sala de espera, compartida entre la ruta de consulta (cola.js)
// y el registro (registros.js), para que ambas usen exactamente el mismo cálculo.
const db = require('./db/db');
const { SALA_ESPERA_PERSONAS_POR_GRUPO, SALA_ESPERA_INTERVALO_MS } = require('./config');

// Cuántas personas ya deberían haber sido admitidas, según cuánto tiempo pasó
// desde que se formó la primera persona en la fila.
function calcularAdmitidos() {
  const primera = db.prepare('SELECT MIN(creado_en) AS min FROM cola').get().min;
  if (!primera) return 0;
  const transcurrido = Date.now() - new Date(primera).getTime();
  const grupos = Math.floor(Math.max(0, transcurrido) / SALA_ESPERA_INTERVALO_MS) + 1;
  return grupos * SALA_ESPERA_PERSONAS_POR_GRUPO;
}

// Posición de un ticket en la fila (1 = primer lugar), o null si no existe.
function posicionDe(ticket) {
  const fila = db.prepare('SELECT id FROM cola WHERE id = ?').get(ticket);
  if (!fila) return null;
  return db.prepare('SELECT COUNT(*) AS n FROM cola WHERE id <= ?').get(ticket).n;
}

function yaEsSuTurno(ticket) {
  const posicion = posicionDe(ticket);
  if (posicion === null) return false;
  return posicion <= calcularAdmitidos();
}

module.exports = { calcularAdmitidos, posicionDe, yaEsSuTurno };
